# processamento-imagem-desafioDIO

Descricao.
O pacote processamento-imagem-desafioDIO pode ser usado para: 
    Processar:
		- Correspondencia de histograma
		- Similaridade estrutural
		- Redimensionar imagem
    Executar:
		- Ler imagem
		- Salvar imagem
		- Plotar imagem
		- Plotar resultado
		- Plotar histograma

## Instalacao

Use o gerenciador de pacote [pip](https://pip.pypa.io/en/stable/) para instalar o pacote processamento-imagem-desafioDIO

```bash
pip install processamento-imagem-desafioDIO
```

## Autor
Rafael Morais

## Licenca
[MIT](https://choosealicense.com/licenses/mit/)